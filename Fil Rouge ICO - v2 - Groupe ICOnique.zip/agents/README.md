# Fil Rouge ICO - v2 - Groupe ICOnique
Yishan Sun, Simon Kurney, Pablo Aldana, Cédric Jung, Baptiste Deconihout, Zoé Poupardin

Dans cette version, on a simplement créé des agents qui correspondaient à chaque solution et nous avons créé un pool de solution. 

Il nous reste à avoir une réele stratégie de choix des solutions à retenir dans le pool de solution.